# Project Manifest: WhatsApp Voice Price Assistant PoC

## Goal
To build a Proof of Concept (PoC) for an "Asistente de Carga de Precios por Voz para WhatsApp" designed for non-technical retail merchants to update product prices in real-time via WhatsApp voice notes.

## Architectural Guidelines
- **Zero-Tolerance to Errors:** The system must not guess or invent data. If an audio message is ambiguous or invalid, the flow is aborted.
- **Interactive Validation:** The system must send a formatted validation message with interactive confirmation buttons (SÍ, GUARDAR / NO, CANCELAR) before updating the database.
- **FastAPI Backend:** A fast, asynchronous webhook handler to receive WhatsApp message events, handle speech-to-text, parse structured entities, and write to Google Sheets.

## Project Structure
- `/app_result/PROJECT_MANIFEST.md` - This manifest
- `/app_result/bsp/BSP.md` - Business Rules & User Experience Spec
- `/app_result/src/main.py` - FastAPI app handling Webhooks & Business Flow
- `/app_result/src/ai_integration.py` - Whisper Transcription & LLM Extraction
- `/app_result/src/sheets_integration.py` - Google Sheets Sync & Persistence
- `/app_result/deploy/Dockerfile` - Deployment spec
- `/app_result/README.md` - Configuration & Setup Guide
