# Business Specification (BSP) - Voice Price Assistant

## 1. Business Logic
- Input: User audio note or text on WhatsApp.
- Transcription: OpenAI Whisper (v3) to convert audio to raw text.
- Extraction: OpenAI GPT-4o-mini structured output to capture:
  - Product Name (entity)
  - Price (float)
  - Action (up/down/fixed)
- Confirmation: Interactive message with [SÍ, GUARDAR] / [NO, CANCELAR] buttons.
- Finalization: Write to Google Sheet (row: Product, OldPrice, NewPrice, Timestamp).

## 2. User Interface Specs
- WhatsApp text message with bold markers for key updates.
- Use of emojis (📈, 📉, 🏷️, 💸) for visual feedback.
- Buttons for rapid confirmation.

## 3. Data Integrity
- Ensure the extraction result contains the required data before presenting the confirmation screen.
- Never write to the Google Sheet without confirmation.
